import React, { Component } from 'react';
import './LoginFormValidation.css';
import { BrowserRouter as Router, Route, Link } from "react-router-dom";
import ProductList from './ProductList'

class productUpdate extends Component {

    constructor(props){
        super(props);
        this.state=({
            productId : ' ',
            quantityOnHand : ' ',
            errors :{
                productId:' ',
                quantityOnHand:' '
            }
        })
        this.doValidation = this.doValidation.bind(this);
        this.productListUpdate = this.productListUpdate.bind(this);
    }

    productListUpdate(){
        
    }

    doValidation(event){
        event.preventDefault();
        const{name , value} = event.target;

        let errors = this.state.errors;

        switch(name){
            case 'productId':
               
                        errors.productId = value.length <1 ? 'Product Id Cannot be Empty':''
                        break;
            case 'quantityOnHand':
                        if(value.length==0)
                        errors.quantityOnHand = " Updated Quantity cannot be Empty!! ";
                        else
                        errors.quantityOnHand = value<0 ? 'Quantity cannot be negative':' '
                        
                        break;
            default:
                    break;
        }

        this.setState({
            errors , [name] : value
        })
    }
    render() {
        return (
            <div className="wrapper">
                <div className="form-wrapper">
                <form onSubmit={this.productListUpdate}>
                    <div>
                         <label htmlFor="productId">Product ID</label>
                        <input type="text" name="productId" onChange={this.doValidation}></input>
                    </div>
                    <span className='error'>{this.state.errors.productId}</span>

                    <div>
                    <label htmlFor="quantityOnHand">QuantityOnHand</label>
                    <input type="text" name="quantityOnHand" onChange={this.doValidation}></input>
                    </div>
                    <span className='error'>{this.state.errors.quantityOnHand}</span>
                    <div>
                    
                    <input type="submit" value="Update"></input>
                   
                    </div>
                </form>
                </div>
                
            </div>
        );
    }
}

export default productUpdate;