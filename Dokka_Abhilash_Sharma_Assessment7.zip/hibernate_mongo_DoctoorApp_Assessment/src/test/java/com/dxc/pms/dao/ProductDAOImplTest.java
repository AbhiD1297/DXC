//package com.dxc.pms.dao;
//
//import java.util.List;
//
//import com.dxc.pms.dao.ProductDAOImpl;
//import com.dxc.pms.model.Product;
//
//import junit.framework.TestCase;
//
//public class ProductDAOImplTest extends TestCase {
//ProductDAOImpl daoImpl;
//
//	protected void setUp() throws Exception {
//		super.setUp();
//		daoImpl=new ProductDAOImpl();
//	}
//
//	public void testGetProduct() {
//		Product product=new Product(1809, "pop", 3, 3);
//		Product product2=daoImpl.getProduct(1809);
//		assertEquals(product.getProductName(), product2.getProductName());
//		
//		
//	}
//
//	public void testGetAllProducts() {
//		int size=0;
//		int size2=daoImpl.getAllProducts().size();
//		assertNotSame(size, size2);
//	
//	}
//
//	public void testAddProduct() {
//		Product product=new Product(190, "pop", 3, 3);
//		List<Product> list=daoImpl.getAllProducts();
//		daoImpl.addProduct(product);
//		List<Product> list2=daoImpl.getAllProducts();
//		assertNotSame(list.size(), list2.size());
//	}
//
//	public void testDeleteProduct() {
//		Product product=new Product(3, "pop", 3, 3);
//		daoImpl.addProduct(product);
//		int size1=daoImpl.getAllProducts().size();
//		daoImpl.deleteProduct(103);
//		int size2=daoImpl.getAllProducts().size();
//		assertNotSame(size1, size2);
//		
//		
//		
//	}
//
//	public void testUpdateProduct() {
//		Product product=new Product(95, "pop", 3, 3);
//		daoImpl.addProduct(product);
//		Product product2=new Product(95, "pop", 3, 3);
//		daoImpl.updateProduct(product2);
//		assertEquals(product.getProductName(), product2.getProductName());
//	}
//
//	public void testIsProductExists() {
//		
//		boolean actual=daoImpl.isProductExists(909090);
//		assertEquals(false, actual);
//	}
//
//	public void testIsProductExists2() {
//		Product product=new Product(5, "pop", 3, 3);
//		daoImpl.addProduct(product);
//		boolean actual=daoImpl.isProductExists(5);
//		assertEquals(true, actual);
//	}
//}