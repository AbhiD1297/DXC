package com.dxc.pts.model.DAO;

import java.util.List;

import com.dxc.pts.model.Passenger;

public interface PassengerDAO {
		public Passenger getPassengerInfo(int pnrNo);
		public List<Passenger> getAllPassengers();
		public void addPassenger(Passenger passenger);
		public void removePassenger(int pnrNo);
		public void UpdatePassenger(Passenger passenger);
		
}
