package com.dxc.pms.model;

import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.search.annotations.IndexedEmbedded;

@Entity
@Table(name ="Doctor")
public class Doctor {
	
	@Id
	private int doctorId;

	private String doctorName;
	
	private int doctorFees;
	
	private hospDetails hospDetails;
	
	public Doctor() {
		// TODO Auto-generated constructor stub
	}

	public Doctor(int doctorId, String doctorName, int doctorFees, com.dxc.pms.model.hospDetails hospDetails) {
		super();
		this.doctorId = doctorId;
		this.doctorName = doctorName;
		this.doctorFees = doctorFees;
		this.hospDetails = hospDetails;
	}

	public int getDoctorId() {
		return doctorId;
	}

	public void setDoctorId(int doctorId) {
		this.doctorId = doctorId;
	}

	public String getDoctorName() {
		return doctorName;
	}

	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}

	public int getDoctorFees() {
		return doctorFees;
	}

	public void setDoctorFees(int doctorFees) {
		this.doctorFees = doctorFees;
	}

	public hospDetails getHospDetails() {
		return hospDetails;
	}

	public void setHospDetails(hospDetails hospDetails) {
		this.hospDetails = hospDetails;
	}

	@Override
	public String toString() {
		return "Doctor [doctorId=" + doctorId + ", doctorName=" + doctorName + ", doctorFees=" + doctorFees
				+ ", hospDetails=" + hospDetails + "]";
	}
	
	
}
