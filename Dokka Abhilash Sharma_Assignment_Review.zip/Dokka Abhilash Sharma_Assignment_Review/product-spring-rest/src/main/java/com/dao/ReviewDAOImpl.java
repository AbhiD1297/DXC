package com.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;

import org.springframework.stereotype.Repository;

import com.model.Product;
import com.model.Review;

@Repository
public class ReviewDAOImpl implements ReviewDAO {

	@Autowired
	ProductDAO productDAO;
	@Autowired
	MongoTemplate mongoTemplate;

	Product product = new Product();
	Review review = new Review();

	@Override
	public List<Review> getAllReview(int productId) {

		product = productDAO.getProduct(productId);

		List<Review> allReview = product.getReview();
		System.out.println(allReview);

		return allReview;

	}

	@Override
	public boolean addReview(int productId, Review review) {

		product = productDAO.getProduct(productId);

		System.out.println(product);

		List<Review> allReview = new ArrayList<Review>();
		allReview = product.getReview();
		System.out.println(allReview);

		System.out.println(review);

		allReview.add(review);

		System.out.println(allReview);
		product.setReview(allReview);

		System.out.println("Inside DAO :" + review);
		System.out.println("Inside DAO :" + product);

		mongoTemplate.save(product, "product");
		return true;
	}

	@Override
	public boolean deleteReview(int productId, int reviewId) {
		// TODO Auto-generated method stub

		product = productDAO.getProduct(productId);

		List<Review> allReview = new ArrayList<Review>();
		allReview = product.getReview();
		System.out.println(allReview);

		for (int i = 0; i < allReview.size(); i++) {
			if (allReview.get(i).getReviewId() == reviewId) {
				allReview.remove(i);
			}
		}

		product.setReview(allReview);
		mongoTemplate.save(product, "product");

		return true;
	}

	@Override
	public Review getReview(int productId, int reviewId) {
		// TODO Auto-generated method stub
		product = productDAO.getProduct(productId);

		List<Review> allReview = new ArrayList<Review>();
		allReview = product.getReview();
		System.out.println(allReview);

		for (int i = 0; i < allReview.size(); i++) {
			if (allReview.get(i).getReviewId() == reviewId) {
				review = allReview.get(i);
			}
		}

		return review;
	}

	@Override
	public boolean updateReview(int productId, Review review) {
		// TODO Auto-generated method stub

		product = productDAO.getProduct(productId);

		List<Review> allReviews = product.getReview();

		for (Review x : allReviews) {
			if (x.getReviewId() == review.getReviewId()) {

				System.out.println(x);

				allReviews.remove(x);

				allReviews.add(review);

				product.setReview(allReviews);

				mongoTemplate.save(product, "product");
			}
		}

		return true;

	}

}
