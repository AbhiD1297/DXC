package com.assessment.ques3;

import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

public class msn {

	public static WebDriver driver;
	public String Browser="chrome";
	
	@Test
	public void testcase() throws Throwable{
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		driver=new ChromeDriver(); //OpenBrowser
		
		driver.get("https://www.msn.com/en-in/"); //open url
		driver.manage().window().maximize(); //maximize browser
		driver.manage().timeouts().implicitlyWait(25, TimeUnit.SECONDS);
		
		//clicking on onenote.......
		driver.findElement(By.xpath("//h3[contains(text(),'OneNote')]")).click();
		
		//getting tabids.....
		Set<String> tabs= driver.getWindowHandles();
		Iterator<String> iterator = tabs.iterator();
		String mainid = iterator.next();
		String t1 = iterator.next();
		
		//switching driver reference to next tab......
		driver.switchTo().window(t1);
		
		driver.findElement(By.xpath("//input[@id='i0116']")).sendKeys("6457645879");
		Thread.sleep(1000);
		
		//closing the tab
		driver.close();
		
		//switching back reference to main.....
		driver.switchTo().window(mainid);
		
		//clicking on Skype link......
		driver.findElement(By.xpath("//h3[contains(text(),'Skype')]")).click();
		Thread.sleep(1500);
		
		//closing browser
		driver.quit();
		
		
		
	
	}
}
