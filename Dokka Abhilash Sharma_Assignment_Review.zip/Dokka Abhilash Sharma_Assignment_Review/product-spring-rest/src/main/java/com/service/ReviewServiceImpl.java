package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.ReviewDAO;
import com.model.Product;
import com.model.Review;

@Service
public class ReviewServiceImpl implements ReviewService {

	@Autowired
	ReviewDAO reviewDAO;

	Product product;

	@Override
	public List<Review> getAllReview(int productId) {
		System.out.println(productId);
		return reviewDAO.getAllReview(productId);

	}

	@Override
	public boolean addReview(int productId, Review review) {
		return reviewDAO.addReview(productId, review);
	}

	@Override
	public boolean deleteReview(int productId, int reviewId) {
		// TODO Auto-generated method stub
		return reviewDAO.deleteReview(productId, reviewId);
	}

	@Override
	public Review getReview(int productId, int reviewId) {
		// TODO Auto-generated method stub
		return reviewDAO.getReview(productId, reviewId);
	}

	@Override
	public boolean updateReview(int productId, Review review) {
		// TODO Auto-generated method stub
		return reviewDAO.updateReview(productId, review);
	}

}
