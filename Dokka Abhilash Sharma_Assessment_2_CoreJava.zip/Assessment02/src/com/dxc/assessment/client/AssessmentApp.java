package com.dxc.assessment.client;

import java.util.Scanner;

import com.dxc.assessment.model.DAO.UsersDAOimpl;

public class AssessmentApp {
		private String username;
		private String password;
	
	public void display() {
		UsersDAOimpl user = new UsersDAOimpl();
		boolean choice = true;
		
		while(choice) {
		System.out.println("Please Enter your Credentials below: ");
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter username: ");
		username = sc.next();
		System.out.println("Enter your Password: ");
		password = sc.next();
		
		if(user.authenticate(username, password)){
			training train = new training();
			train.display();
		}
		else {
			System.out.println("Entered Credentials are Wrong....");
		}
		
		System.out.println("You have been logged out.Do you wish to continue (Y/N): ");
		String option = sc.next();
		if(option.charAt(0)=='Y' || option.charAt(0)=='y') {
			choice=true;}
			else
				choice = false;
		}
	}
	}

