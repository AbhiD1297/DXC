package com.dxc.pts.model.DAO;

import java.util.ArrayList;
import java.util.List;

import com.dxc.pts.model.Passenger;

public class PassengerDAOimpl implements PassengerDAO {
	
	List<Passenger> passengers = new ArrayList<Passenger>();

	public PassengerDAOimpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public Passenger getPassengerInfo(int pnrNo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Passenger> getAllPassengers() {
		// TODO Auto-generated method stub
		return passengers;
	}

	@Override
	public void addPassenger(Passenger passenger) {
		// TODO Auto-generated method stub
		passengers.add(passenger);

	}

	@Override
	public void removePassenger(int pnrNo) {
		// TODO Auto-generated method stub

	}

	@Override
	public void UpdatePassenger(Passenger passenger) {
		// TODO Auto-generated method stub

	}

}
