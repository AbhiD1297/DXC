package com.dxc.pms.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.dxc.pms.model.Doctor;
import com.dxc.pms.util.HibernateUtil;

public class DoctorDAOImpl implements DoctorDAO {
	
	SessionFactory sf = HibernateUtil.getSessionFactory();

	@Override
	public Doctor getDoctor(int doctorId) {
		
		Session session = sf.openSession();
		Doctor doctor = (Doctor) session.get(Doctor.class, doctorId);
		return doctor;
	}

	@Override
	public List<Doctor> getAllDoctors() {
		
		Session session = sf.openSession();
		Query query = session.createQuery("from Doctor");
		return query.list();
	}

	@Override
	public void addDoctor(Doctor doctor) {
		
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		session.save(doctor);
		transaction.commit();
		session.close();
		System.out.println(doctor.getDoctorName() + " Saved Successfulli in the database");
		

	}

	@Override
	public void deleteDoctor(int doctorId) {
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		Doctor doctor = (Doctor) session.get(Doctor.class, doctorId);
	
		session.delete(doctor);
		transaction.commit();
		session.close();

	}

	@Override
	public void updateDoctor(Doctor newdoctor) {
		Session session = sf.openSession();
Transaction transaction = session.beginTransaction();
		
		Doctor oldDoctor = (Doctor) session.get(Doctor.class, newdoctor.getDoctorId());
		oldDoctor.setDoctorName(newdoctor.getDoctorName());
		oldDoctor.setDoctorFees(newdoctor.getDoctorFees());
		oldDoctor.setHospDetails(newdoctor.getHospDetails());
		
		transaction.commit();
		session.close();

	}

	@Override
	public boolean isDoctorExists(int doctorId) {
		Session session = sf.openSession();
		
		Doctor doctor = (Doctor) session.get(Doctor.class, doctorId);
		if(doctor == null)
			return false;
		else
			return true;
	
	}

	@Override
	public List<String> getAllDoctorNames() {
		Session session = sf.openSession();
		Query query = session.createQuery("select doctorName from Doctor");
		List<String> pr = query.list();
//		Iterator <String> iterator = pr.iterator();
//		
//		while(iterator.hasNext()) {
//			String p = iterator.next();
//			System.out.println(p);
//		}
		return pr;
	}

	@Override
	public List<Doctor> getDoctor(String doctorName) {
		
		Session session = sf.openSession();
		Query query = session.createQuery("from Doctor  where doctorName = :doctorName");
		query.setString("doctorName", doctorName);
		
//		BasicQuery query = new BasicQuery();
		
		return query.list();
	}

}
