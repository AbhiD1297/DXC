package com.dxc.pms.dao;

import java.util.List;

import javax.print.Doc;

import com.dxc.pms.model.Doctor;
import com.dxc.pms.model.hospDetails;

import junit.framework.TestCase;

public class DoctorDAOImplTest extends TestCase {
	
	DoctorDAO dao;

	protected void setUp() throws Exception {

		dao = new DoctorDAOImpl();
	}

	public void testGetDoctor() {
		hospDetails obj = new hospDetails("Vedanta", "Bangalore");
		Doctor doctor = new Doctor(121, "Abhi", 100000, obj);
		dao.addDoctor(doctor);
		Doctor doctor2 = dao.getDoctor(121);
		assertEquals(doctor.getDoctorName(), doctor2.getDoctorName());
		
	}

	public void testGetAllDoctors() {
		hospDetails obj = new hospDetails("JBIMS", "Bangalore");
		Doctor doctor = new Doctor(2, "Prashanth", 1000, obj);
		List<Doctor>list1=dao.getAllDoctors();
		dao.addDoctor(doctor);
		List<Doctor>list2=dao.getAllDoctors();
		assertNotSame(list1.size(), list2.size());
	}

	public void testAddDoctor() {
		hospDetails obj = new hospDetails("Fortis64", "chennai");
		Doctor doctor = new Doctor(5, "Dokka97", 165000, obj);
		List<Doctor> list=dao.getAllDoctors();
		dao.addDoctor(doctor);
		List<Doctor> list2=dao.getAllDoctors();
		assertNotSame(list.size(), list2.size());
	}

	public void testDeleteDoctor() {
		hospDetails obj = new hospDetails("JBIytMS", "Bangalore");
		Doctor doctor = new Doctor(100, "Prashanth", 1000, obj);
		
		dao.addDoctor(doctor);
		List<Doctor> list = dao.getAllDoctors();
		dao.deleteDoctor(100);
		List<Doctor> list2=dao.getAllDoctors();
		assertNotSame(list.size(), list2.size());
	}

	public void testUpdateDoctor() {
		hospDetails obj = new hospDetails("Apollo", "Mumbai");
		Doctor doctor = new Doctor(3, "Abhijit", 65657, obj);
		dao.addDoctor(doctor);
		
		hospDetails obj1 = new hospDetails("Fortis", "Navi Mumbai");
		Doctor newdoctor = new Doctor(3, "Abhijit", 65657, obj1);
		dao.updateDoctor(newdoctor);
		
		assertNotSame(newdoctor.getHospDetails(), doctor.getHospDetails());
	}

	public void testIsDoctorExists() {
		hospDetails obj = new hospDetails("Apollo", "Mumbai");
		Doctor doctor = new Doctor(4, "Dokka12", 654657, obj);
		dao.addDoctor(doctor);
		
		boolean exist = dao.isDoctorExists(4);
		assertEquals(true, exist);
		
		
		
	}

	public void testGetAllDoctorNames() {
		int size1 = dao.getAllDoctorNames().size();
		
		hospDetails obj = new hospDetails("Apollo14", "Mumbai");
		Doctor doctor = new Doctor(6, "Dokka97", 6657, obj);
		
		dao.addDoctor(doctor);
		
		int size2 = dao.getAllDoctorNames().size();
		assertNotSame(size1, size2);
	}
	
	public void testgetDoctorByName() {
		
		hospDetails obj = new hospDetails("Apollo11", "Mumbai");
		Doctor doctor = new Doctor(10, "Dokka1297", 665777, obj);
		dao.addDoctor(doctor);
		
		int size1=0;
		
		List<Doctor> list1 = dao.getDoctor("Dokka1297");
		int size2 = list1.size();
		
		assertNotSame(size1, size2);
	}

}
