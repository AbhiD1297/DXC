package com.dxc.pts.model;

public class Passenger {
	
	private int PnrNo;
	private String Passengername;
	private String Source;
	private int fare;
		
	public Passenger(int pnrNo, String passengername, String source, int fare) {
		super();
		PnrNo = pnrNo;
		Passengername = passengername;
		Source = source;
		this.fare = fare;
	}
	public Passenger() {
		// TODO Auto-generated constructor stub
	}
	public int getPnrNo() {
		return PnrNo;
	}
	public void setPnrNo(int pnrNo) {
		PnrNo = pnrNo;
	}
	public String getPassengername() {
		return Passengername;
	}
	public void setPassengername(String passengername) {
		Passengername = passengername;
	}
	public String getSource() {
		return Source;
	}
	public void setSource(String source) {
		Source = source;
	}
	public int getFare() {
		return fare;
	}
	public void setFare(int fare) {
		this.fare = fare;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((Passengername == null) ? 0 : Passengername.hashCode());
		result = prime * result + PnrNo;
		result = prime * result + ((Source == null) ? 0 : Source.hashCode());
		result = prime * result + fare;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Passenger other = (Passenger) obj;
		if (Passengername == null) {
			if (other.Passengername != null)
				return false;
		} else if (!Passengername.equals(other.Passengername))
			return false;
		if (PnrNo != other.PnrNo)
			return false;
		if (Source == null) {
			if (other.Source != null)
				return false;
		} else if (!Source.equals(other.Source))
			return false;
		if (fare != other.fare)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "\n Passenger [PnrNo=" + PnrNo + ", Passengername=" + Passengername + ", Source=" + Source + ", fare="
				+ fare + "]";
	}
	
	
}
