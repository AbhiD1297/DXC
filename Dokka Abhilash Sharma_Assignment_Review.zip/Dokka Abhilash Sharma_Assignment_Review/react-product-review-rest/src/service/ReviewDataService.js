import axios from "axios";
const REVIEW_API_URL = 'http://localhost:8080/reviews'

class ReviewDataService {

    getAllReviews(productId) {
        return axios.get(`${REVIEW_API_URL}/${productId}`);
     }

     addReview(review, productId) {
         return axios.post(`${REVIEW_API_URL}/${productId}`, review)
     }

     deleteReview(productId, reviewId) {
         return axios.delete(`${REVIEW_API_URL}/${productId}/${reviewId}`)
     }

     updateReview(productId, review) {
         return axios.put(`${REVIEW_API_URL}/${productId}`, review)
     }

     getReview(productId, reviewId) {
         return axios.get(`${REVIEW_API_URL}/${productId}/${reviewId}`)
     }

}
export default new ReviewDataService();