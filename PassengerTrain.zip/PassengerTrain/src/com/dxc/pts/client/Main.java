package com.dxc.pts.client;

import java.util.Scanner;

import com.dxc.pts.model.Passenger;
import com.dxc.pts.model.DAO.PassengerDAO;
import com.dxc.pts.model.DAO.PassengerDAOimpl;

public class Main {

	public static void main(String[] args) { 
		PassengerDAOimpl pd=new PassengerDAOimpl();
		System.out.println("M E N U");
		System.out.println("1. Add Passenger");
		System.out.println("2. Show all Passenger Information");
		System.out.println("3. E X I T");
	
		int choice;
		
		while(true) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your Choice(1-3)");
		choice = sc.nextInt();
		int pnrno, fare;
		String Passengername, Source;
						
		switch (choice) {
		case 1:	System.out.println("Enter PNR number: ");
				pnrno=sc.nextInt();
			
				System.out.println("Enter Passenger name: ");
				Passengername = sc.next();
				
				System.out.println("Enter Source: ");
				Source = sc.next();
			
				System.out.println("Enter fare: ");
				fare = sc.nextInt();
				
				
				pd.addPassenger(new Passenger(pnrno, Passengername, Source, fare));
				
				break;
				
		case 2: System.out.println(pd.getAllPassengers());
				break;
				
		case 3: System.out.println("Thanks for Using my program");
				System.exit(0);
				break;
	
		default: System.out.println("Bhag Yahan Se");
				System.exit(0);
				 break;
		}
		}
	}

}
