package com.dxc.assessment.model.DAO;

import java.util.List;

import com.dxc.assessment.model1.Training;

public interface TrainingDAO {
	
	public List<Training> getallrecords();
	public void getrecordsonebyone();

}
