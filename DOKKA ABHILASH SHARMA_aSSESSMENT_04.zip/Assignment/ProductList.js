import React, { Component } from 'react';
import ProductDisplay from './ProductDisplay';
import { BrowserRouter as Router, Route, Link } from "react-router-dom";
import ProductDetails from './ProductDetails';
import './LoginFormValidation.css';
class ProductList extends Component {
    constructor(props){
        super(props);
        this.state=({
            productId : ' ',
            quantityOnHand : ' ',
            errors :{
                productId:' ',
                quantityOnHand:' '
            },
            productList : [
                {
                    productId: 1001,
                    productName: 'Watch',
                    quantityOnHand: 2000,
                    price: 10000
                },
                {
                    productId: 1002,
                    productName: 'Mouse',
                    quantityOnHand: 29,
                    price: 180000
                },
                {
                    productId: 1003,
                    productName: 'Laptop',
                    quantityOnHand: 29,
                    price: 122
                },
                {
                    productId: 10113,
                    productName: 'Presenter',
                    quantityOnHand: 29,
                    price: 122
                },
    
                {
                    productId: 111003,
                    productName: 'Marker',
                    quantityOnHand: 29,
                    price: 122
                },
            ]
        })
        this.doValidation = this.doValidation.bind(this);
        this.productListUpdate = this.productListUpdate.bind(this);
     
    }

    productListUpdate(e)
    {
        e.preventDefault();
        var quantity = this.state.quantityOnHand;
        var productId = this.state.productId;

        var arr = this.state.productList;
        for(var i=0;i<arr.length;i++){
            if(arr[i].productId==productId){
                arr[i].quantityOnHand = quantity;
                break;
            }
        }
        this.setState({
            productList:arr
        });

    }

    doValidation(event){
        event.preventDefault();
        const{name , value} = event.target;

        let errors = this.state.errors;

        switch(name){
            case 'productId':
               
                        errors.productId = value.length <1 ? 'Product Id Cannot be Empty':''
                        break;
            case 'quantityOnHand':
                        if(value.length==0)
                        errors.quantityOnHand = " Updated Quantity cannot be Empty!! ";
                        else
                        errors.quantityOnHand = value<0 ? 'Quantity cannot be negative':' '
                        
                        break;
            default:
                    break;
        }

        this.setState({
            errors , [name] : value
        })
    }
    render() {
        
        return (
            <div>
                {this.state.productList.map((product, index) =>
                   
                        <ProductDisplay render={({ match }) => match={match}}
                            nn={index}
                            key={index}
                            product={product}
                        ></ProductDisplay>
                    

                )}

                <div className="wrapper">
                <div className="form-wrapper">
                <form >
                    <div>
                         <label htmlFor="productId">Product ID</label>
                        <input type="text" name="productId" onChange={this.doValidation}></input>
                    </div>
                    <span className='error'>{this.state.errors.productId}</span>

                    <div>
                    <label htmlFor="quantityOnHand">QuantityOnHand</label>
                    <input type="text" name="quantityOnHand" onChange={this.doValidation}></input>
                    </div>
                    <span className='error'>{this.state.errors.quantityOnHand}</span>
                    <div>
                    
                    <button onClick={this.productListUpdate}>Update</button> 
                   
                    </div>
                </form>
                </div>
                
            </div>

               
            </div>

        );
    }
}
export default ProductList;
