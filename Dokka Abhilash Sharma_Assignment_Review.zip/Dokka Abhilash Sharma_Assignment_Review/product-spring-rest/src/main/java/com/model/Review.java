package com.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class Review {

	@Id
	private int reviewId;
	private String review;
	private String reviewRating;
	
	public Review() {
		// TODO Auto-generated constructor stub
	}

	public Review(int reviewId, String review, String reviewRating) {
		super();
		this.reviewId = reviewId;
		this.review = review;
		this.reviewRating = reviewRating;
	}

	public int getReviewId() {
		return reviewId;
	}

	public void setReviewId(int reviewId) {
		this.reviewId = reviewId;
	}

	public String getReview() {
		return review;
	}

	public void setReview(String review) {
		this.review = review;
	}

	public String getReviewRating() {
		return reviewRating;
	}

	public void setReviewRating(String reviewRating) {
		this.reviewRating = reviewRating;
	}

	@Override
	public String toString() {
		return "Review [reviewId=" + reviewId + ", review=" + review + ", reviewRating=" + reviewRating + "]";
	}
	
}