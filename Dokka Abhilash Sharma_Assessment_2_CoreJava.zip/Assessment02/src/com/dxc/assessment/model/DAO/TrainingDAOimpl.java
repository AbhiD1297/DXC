package com.dxc.assessment.model.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.dxc.assessment.model1.Training;
import com.dxc.assessment.dbcon.DBConnection;

public class TrainingDAOimpl implements TrainingDAO {

	
	Connection connection = DBConnection.getConnection();
	private static final String FETCH_PASSENGER_ALL = "select * from training";
	
	
	public TrainingDAOimpl() {
		// TODO Auto-generated constructor stub
	}

	public List<Training> getallrecords() {
		List<Training> alltrainee = new ArrayList<Training>();
		try {
			Statement stat = connection.createStatement();
			
			ResultSet res = stat.executeQuery(FETCH_PASSENGER_ALL);
			while(res.next()) {
				Training object = new Training();
				object.setSapId(res.getInt(1));
				object.setEmployeeName(res.getString(2));
				object.setStream(res.getString(3));
				object.setPercentage(res.getInt(4));
				alltrainee.add(object);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return alltrainee;
	}

	public void getrecordsonebyone() {
		Scanner sc = new Scanner(System.in);
		
		try {
			Statement stat = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
					ResultSet.CONCUR_UPDATABLE);
			ResultSet res = stat.executeQuery(FETCH_PASSENGER_ALL);
			while(res.next()) {
				System.out.println("You are Updating the percentage of: "+ res.getString(2));
				System.out.println("Enter percentage you want to update: ");
				int percent = sc.nextInt();
				res.updateInt(4, percent);
				res.updateRow();
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	
	}

}
