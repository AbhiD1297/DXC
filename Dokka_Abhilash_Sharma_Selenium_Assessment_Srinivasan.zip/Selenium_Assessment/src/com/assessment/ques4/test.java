package com.assessment.ques4;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class test {

	public WebDriver driver;
	public String Browser="chrome";
	@Test
	
	
		
		public void testcase1() throws Throwable{
			//To choose which browser we want
			int counter=0;
				System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
				driver=new ChromeDriver(); //OpenBrowser
			
			driver.get("https://www.yahoo.com/"); //open url
			
			driver.manage().window().maximize(); //maximize browser
			//To get all elements with the tag a
			List<WebElement> findElements = driver.findElements(By.tagName("a"));
			for(int i=0;i<findElements.size();i++){
				//To check if the news link exists
				if(findElements.get(i).getText().contains("News")){
					counter+=1;
				}

	}
			System.out.println("Number of news links that exists are: "+counter);
		}
}
