package com.dxc.assessment.model.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.dxc.assessment.dbcon.DBConnection;

public class UsersDAOimpl implements UsersDAO {
	
	Connection connection = DBConnection.getConnection();
	private static final String FETCH_USER = "select * from users where Username = ? and Password = ?";
	

	public UsersDAOimpl() {
		// TODO Auto-generated constructor stub
	}

	public boolean authenticate(String username, String password) {
		boolean valid = false;
	try {
		PreparedStatement stat = connection.prepareStatement(FETCH_USER);
		stat.setString(1, username);
		stat.setString(2, password);
		ResultSet res = stat.executeQuery();
		if(res.next())
			valid = true;
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	return valid;
	

	}

}
