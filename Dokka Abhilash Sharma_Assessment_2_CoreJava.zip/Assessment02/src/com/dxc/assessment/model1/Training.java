package com.dxc.assessment.model1;

public class Training {

	private int SapId;
	private String EmployeeName;
	private String Stream;
	private int percentage;
	
	public Training() {
		// TODO Auto-generated constructor stub
	}

	public Training(int sapId, String employeeName, String stream, int percentage) {
		super();
		SapId = sapId;
		EmployeeName = employeeName;
		Stream = stream;
		this.percentage = percentage;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((EmployeeName == null) ? 0 : EmployeeName.hashCode());
		result = prime * result + SapId;
		result = prime * result + ((Stream == null) ? 0 : Stream.hashCode());
		result = prime * result + percentage;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Training other = (Training) obj;
		if (EmployeeName == null) {
			if (other.EmployeeName != null)
				return false;
		} else if (!EmployeeName.equals(other.EmployeeName))
			return false;
		if (SapId != other.SapId)
			return false;
		if (Stream == null) {
			if (other.Stream != null)
				return false;
		} else if (!Stream.equals(other.Stream))
			return false;
		if (percentage != other.percentage)
			return false;
		return true;
	}

	public int getSapId() {
		return SapId;
	}

	public void setSapId(int sapId) {
		SapId = sapId;
	}

	public String getEmployeeName() {
		return EmployeeName;
	}

	public void setEmployeeName(String employeeName) {
		EmployeeName = employeeName;
	}

	public String getStream() {
		return Stream;
	}

	public void setStream(String stream) {
		Stream = stream;
	}

	public int getPercentage() {
		return percentage;
	}

	public void setPercentage(int percentage) {
		this.percentage = percentage;
	}

	@Override
	public String toString() {
		return " \n Training [SapId=" + SapId + ", EmployeeName=" + EmployeeName + ", Stream=" + Stream + ", percentage="
				+ percentage + "]";
	}
	

}
