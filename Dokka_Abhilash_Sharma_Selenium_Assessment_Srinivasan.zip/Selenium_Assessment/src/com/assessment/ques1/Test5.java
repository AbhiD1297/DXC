package com.assessment.ques1;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class Test5 {
	
	public WebDriver driver;
	public String Browser="chrome";
	@Test
	public void testcase(){
		SoftAssert st=new SoftAssert();
		
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		driver=new ChromeDriver(); //OpenBrowser
		
		driver.get("http://in5cg9152vxc:9000/login.do");//opening URL
		driver.manage().window().maximize(); //maximize browser
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		//Login
		driver.findElement(By.xpath("//input[@name='username']")).sendKeys("admin");
		driver.findElement(By.xpath("//input[@name='pwd']")).sendKeys("manager");
		driver.findElement(By.xpath("//a[@id='loginButton']")).click();
		
		//click on Task
		driver.findElement(By.xpath("//a[@class='content tasks']//img[@class='sizer']")).click();
		
		//click on Projects and Customers
		driver.findElement(By.xpath("//a[contains(text(),'Projects & Customers')]")).click();
		
		//click on create new project......
		driver.findElement(By.xpath("//body/div[@id='container']/form[@id='customersProjectsForm']/table[@class='mainContentPadding rightPadding']/tbody/tr/td/table/tbody/tr/td/table/tbody/tr/td/input[2]")).click();
		
		//Selecting a customer
		Select customer = new Select(driver.findElement(By.xpath("//select[@name='customerId']")));
		customer.selectByValue("11");
		
		//Entering Project Name and Description
		driver.findElement(By.xpath("//input[@name='name']")).sendKeys("Project B");
		driver.findElement(By.xpath("//textarea[@name='description']")).sendKeys("Project Description B");
		
		//Selecting a radio button.......
		driver.findElement(By.xpath("//input[@id='add_tasks_action']")).click();
		
		//Click on create Project
		driver.findElement(By.xpath("//input[@name='createProjectSubmit']")).click();
		
		//verify success message.......
				try{
					driver.findElement(By.xpath("//span[@class='successmsg']")).isDisplayed();
					//LogOut
					driver.findElement(By.xpath("//a[@id='logoutLink']")).click();
				}catch(Throwable t){
					st.fail("Success msg is not being displayed......");
					//LogOut
					driver.findElement(By.xpath("//a[@id='logoutLink']")).click();
					driver.findElement(By.xpath("//input[@id='DiscardChangesButton']")).click();					
				}
				
				driver.quit();//Close Browser
				
				st.assertAll();
	}
}
