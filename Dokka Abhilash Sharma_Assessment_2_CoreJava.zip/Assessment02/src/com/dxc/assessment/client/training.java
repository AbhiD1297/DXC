package com.dxc.assessment.client;

import java.util.Scanner;

import com.dxc.assessment.model.DAO.TrainingDAOimpl;

public class training {

	public void display() {
		int option;
		Scanner sc = new Scanner(System.in);
		TrainingDAOimpl train = new TrainingDAOimpl();
		System.out.println("M E N U");
		System.out.println("1. Display all the records");
		System.out.println("2. Display Records one by one and Update their percentages");
		System.out.println("3. EXIT");
		
		System.out.println("Enter your Option(1-3): ");
		option = sc.nextInt();
		
		switch(option) {
		case 1: System.out.println(train.getallrecords());
				break;
				
		case 2: train.getrecordsonebyone();
				break;
				
		case 3: System.out.println("Thank you for using my program");
				System.exit(0);
				break;
				
		default: System.out.println("Please Enter Correct choice: ");
				break;
		}
	}

}
