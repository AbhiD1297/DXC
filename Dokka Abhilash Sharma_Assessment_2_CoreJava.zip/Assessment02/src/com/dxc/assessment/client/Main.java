package com.dxc.assessment.client;

public class Main {

	public static void main(String[] args) {
		AssessmentApp app = new AssessmentApp();
		app.display();
	}

}
