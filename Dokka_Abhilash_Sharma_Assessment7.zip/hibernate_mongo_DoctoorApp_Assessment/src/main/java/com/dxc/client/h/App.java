////package com.dxc.client.h;
//
//import org.hibernate.Session;
//import org.hibernate.SessionFactory;
//import org.hibernate.Transaction;
//import org.hibernate.ogm.cfg.OgmConfiguration;
//
//import com.dxc.model.Customer;
//import com.dxc.model.Employee;
//
///**
// * Hello world!
// *
// */
//public class App 
//{
//    public static void main( String[] args )
//    {
//        OgmConfiguration cfg = new OgmConfiguration();
//        cfg.configure();
//        
//        SessionFactory factory = cfg.buildSessionFactory();
//        Session session = factory.openSession();
//        
//        Transaction transaction = session.beginTransaction();
//        
////        
////        Employee employee = new Employee(2, "Manu", "Kannur", 175000);
////        
////        session.save(employee);
////        
////        Customer customer = new Customer(3, "Jhandu", "Bangalore", 100500);
////        session.save(customer);
//        transaction.commit();
//        
//        System.out.println("Data Stored in MongoDb");
//    }
//}
