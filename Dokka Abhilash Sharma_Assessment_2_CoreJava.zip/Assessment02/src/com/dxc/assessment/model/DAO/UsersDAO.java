package com.dxc.assessment.model.DAO;

public interface UsersDAO {
		public boolean authenticate(String username, String password);
}
